const btnHtml = $("#btn-html");
const btnCss = $("#btn-css");
const btnJs = $("#btn-js");

const renderField = $("#render-field");

// $(document).ready(function () {
//   btnHtml.on("click", function () {
//     $.get("../content/html.txt", function (data) {
//       renderField.html(data);
//     });
//   });
// });
// $(document).ready(function () {
//   btnCss.on("click", function () {
//     $.get("../content/css.txt", function (data) {
//       renderField.html(data);
//     });
//   });
// });
// $(document).ready(function () {
//   btnJs.on("click", function () {
//     $.get("../content/js.txt", function (data) {
//       renderField.html(data);
//     });
//   });
// });

// btnHtml.on("click", () => {
//     const xhr = new XMLHttpRequest()
//     xhr.onreadystatechange = function(){
//         if(this.readyState === 4 && this.status == 200){
//             renderField.html(this.responseText)
//         }
//     }
//     xhr.open('GET', '../content/html.txt', true)
//     xhr.send()
// });

// btnCss.on("click", () => {
//     const xhr = new XMLHttpRequest()
//     xhr.onreadystatechange = function(){
//         if(this.readyState === 4 && this.status == 200){
//             renderField.html(this.responseText)
//         }
//     }
//     xhr.open('GET', '../content/css.txt', true)
//     xhr.send()
// });

// btnJs.on("click", () => {
//     const xhr = new XMLHttpRequest()
//     xhr.onreadystatechange = function(){
//         if(this.readyState === 4 && this.status == 200){
//             renderField.html(this.responseText)
//         }
//     }
//     xhr.open('GET', '../content/js.txt', true)
//     xhr.send()
// });

// function renderDoc(url){
//     const xhr = new XMLHttpRequest()
//     xhr.onreadystatechange = function(){
//         if(this.readyState === 4 && this.status == 200){
//             renderField.html(this.responseText)
//         }
//     }
//     xhr.open('GET', url, true)
//     xhr.send()
// }
// btnHtml.on('click', ()=>{
//     renderDoc('../content/html.txt')
// })
// btnCss.on('click', ()=>{
//     renderDoc('../content/css.txt')
// })
// btnJs.on('click', ()=>{
//     renderDoc('../content/js.txt')
// })

function renderDocJ(url) {
  $.get(url, function (data) {
    renderField.html(data);
  });
}

btnHtml.on("click", function () {
  renderDocJ("../content/html.txt");
});
btnCss.on("click", function () {
  renderDocJ("../content/css.txt");
});
btnJs.on("click", function () {
  renderDocJ("../content/js.txt");
});
